export interface Pregunta {
    difficulty: string;
    question: string;
    correctAnswer: string;
    incorrectAnswer: string[];
}
